package com.journaldev.jsfspring;

import java.util.List;

public interface CarDao {

	public List<String> getCarDetails();

}
