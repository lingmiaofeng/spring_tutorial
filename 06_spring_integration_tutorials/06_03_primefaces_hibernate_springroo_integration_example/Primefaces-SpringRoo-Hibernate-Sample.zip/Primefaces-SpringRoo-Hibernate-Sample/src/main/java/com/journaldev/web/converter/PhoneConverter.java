package com.journaldev.web.converter;
import com.journaldev.jpa.data.Phone;
import org.springframework.roo.addon.jsf.converter.RooJsfConverter;

@RooJsfConverter(entity = Phone.class)
public class PhoneConverter {
}
